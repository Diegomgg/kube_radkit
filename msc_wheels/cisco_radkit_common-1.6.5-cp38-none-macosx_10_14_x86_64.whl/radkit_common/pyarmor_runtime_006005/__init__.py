# Pyarmor 8.4.7 (group), 006005, 2024-03-04T19:51:26.484030
from .pyarmor_runtime import __pyarmor__
