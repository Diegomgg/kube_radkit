# Pyarmor 8.4.7 (group), 006005, 2024-03-04T19:52:26.902653
from .pyarmor_runtime import __pyarmor__
